clear all; close all; clc;

Input_Path = 'E:\2016\Projects\VEI-TF\Code\ours_v2_PCode\images\';
Output_path = 'E:\2016\Projects\VEI-TF\Code\ours_v2_PCode\images\result\';

imgType = '*.tif'; 
images  = dir([Input_Path imgType]);

for idx = 1:length(images)    
    close all;
    images(idx).name
                
    IN_IMG = double(imread([Input_Path images(idx).name]))/255.0;
    Output = VEITF(IN_IMG, images(idx).name, idx);
    
    sub_name = '_result.png';
    name = strcat(images(idx).name,sub_name);
    imwrite((Output), fullfile(Output_path, sprintf(name)));
end




